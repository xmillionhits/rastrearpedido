const rastreio = require('rastrearpedidos');
const { toXML } = require('jstoxml');

class RastreioController {
  async run(req, res) {
    const { codigo } = req.query;

    try {
      const rastreioResult = await rastreio(codigo);
      res.status(200);
      res.json(rastreioResult);
    } catch (error) {
      if (error.error) {
        switch (error.error) {
          case 'validation_error':
            res.status(400);
            res.end(JSON.stringify(error));

            break;
          case 'service_error':
            res.status(404);
            res.end(JSON.stringify(error));

            break;
          default:
            break;
        }

        res.json(error);
        return;
      }

      res.status(500);
      res.json(error);
    }
  }

  async runXML(req, res) {
    const { codigo } = req.query;
    const xmlOptions = {
      header: true,
      indent: '  ',
    };

    try {
      const rastreioResult = await rastreio(codigo);
      res.status(200);
      res.send(
        toXML(
          {
            _name: 'rastrearpedidos',
            _attrs: {
              version: '0.0.1',
            },
            _content: {
              result: rastreioResult,
            },
          },
          xmlOptions
        )
      );
    } catch (error) {
      if (error.error) {
        switch (error.error) {
          case 'validation_error':
            res.status(400);
            res.end(JSON.stringify(error));

            break;
          case 'service_error':
            res.status(404);
            res.end(JSON.stringify(error));

            break;
          default:
            break;
        }

        res.json(error);
        return;
      }

      res.status(500);
      res.json(error);
    }
  }
}

module.exports = new RastreioController();
